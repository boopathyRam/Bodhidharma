import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BooksComponent } from './Books/book.component';
import { AddBooksComponent } from './Books-Add/add.component';
import { EditBooksComponent } from './Books-Edit/edit.component';

const routes: Routes = [
  {
    path: 'Books',
    component: BooksComponent,
    data: { title: 'List of Book' }
  },
  {
    path: 'Books-add',
    component: AddBooksComponent,
    data: { title: 'Add Book' }
  },
  {
    path: 'Books-edit/:id',
    component: EditBooksComponent,
    data: { title: 'Edit Book' }
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
